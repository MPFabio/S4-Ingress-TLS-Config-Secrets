--
-- PostgreSQL database cluster dump
--

\restrict bBVgzFrKfXXHMCE2317gke8Y8KWuNAX929WTj5snlw1dGYuegUXGMr2ZMMgdbHq

SET default_transaction_read_only = off;

SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;

--
-- Roles
--

CREATE ROLE postgres;
ALTER ROLE postgres WITH SUPERUSER INHERIT CREATEROLE CREATEDB LOGIN REPLICATION BYPASSRLS PASSWORD 'SCRAM-SHA-256$4096:HfXm+byZP5iiR95hY375QQ==$kUAhkK97s7OxpY39QkK7t8IR8TZ8hkbUJOj+eNmpLgM=:mMTol+KtUmrHC9hsyJg9sF1aq/0rjd2f22lkG+ZKLms=';

--
-- User Configurations
--








\unrestrict bBVgzFrKfXXHMCE2317gke8Y8KWuNAX929WTj5snlw1dGYuegUXGMr2ZMMgdbHq

--
-- Databases
--

--
-- Database "template1" dump
--

\connect template1

--
-- PostgreSQL database dump
--

\restrict cOaYX3Tqx3DcH2oIivX8wSGGcweushpw1wkCL1PhjT4grphib5AtkPA5GDYweEr

-- Dumped from database version 16.10 (Debian 16.10-1.pgdg13+1)
-- Dumped by pg_dump version 16.10 (Debian 16.10-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict cOaYX3Tqx3DcH2oIivX8wSGGcweushpw1wkCL1PhjT4grphib5AtkPA5GDYweEr

--
-- Database "postgres" dump
--

\connect postgres

--
-- PostgreSQL database dump
--

\restrict eyY6ZzhF6OunVYqZCfBbj5MTfql6pJeGaO22DK78QwDveyB1MgL0RNMEFaPrd5A

-- Dumped from database version 16.10 (Debian 16.10-1.pgdg13+1)
-- Dumped by pg_dump version 16.10 (Debian 16.10-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict eyY6ZzhF6OunVYqZCfBbj5MTfql6pJeGaO22DK78QwDveyB1MgL0RNMEFaPrd5A

--
-- Database "testdb" dump
--

--
-- PostgreSQL database dump
--

\restrict jmYhFdkTv5gk72OqHgxQOH2PdyBD9DWEzHdjQokPpmsjp1pojfkcUPE2scV7U2P

-- Dumped from database version 16.10 (Debian 16.10-1.pgdg13+1)
-- Dumped by pg_dump version 16.10 (Debian 16.10-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: testdb; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE testdb WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE testdb OWNER TO postgres;

\unrestrict jmYhFdkTv5gk72OqHgxQOH2PdyBD9DWEzHdjQokPpmsjp1pojfkcUPE2scV7U2P
\connect testdb
\restrict jmYhFdkTv5gk72OqHgxQOH2PdyBD9DWEzHdjQokPpmsjp1pojfkcUPE2scV7U2P

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id integer NOT NULL,
    name character varying(100),
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, name, created_at) FROM stdin;
1	Alice	2025-11-04 10:49:42.836694
2	Bob	2025-11-04 10:49:42.836694
3	Charlie	2025-11-04 10:49:42.836694
\.


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_id_seq', 3, true);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- PostgreSQL database dump complete
--

\unrestrict jmYhFdkTv5gk72OqHgxQOH2PdyBD9DWEzHdjQokPpmsjp1pojfkcUPE2scV7U2P

--
-- Database "workshop" dump
--

--
-- PostgreSQL database dump
--

\restrict 1wZfsP6GvqG468feYVfKZApXe8h9wioNpTyn5xscZwErVVeIJDh3Oi65pDmJmo8

-- Dumped from database version 16.10 (Debian 16.10-1.pgdg13+1)
-- Dumped by pg_dump version 16.10 (Debian 16.10-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: workshop; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE workshop WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE workshop OWNER TO postgres;

\unrestrict 1wZfsP6GvqG468feYVfKZApXe8h9wioNpTyn5xscZwErVVeIJDh3Oi65pDmJmo8
\connect workshop
\restrict 1wZfsP6GvqG468feYVfKZApXe8h9wioNpTyn5xscZwErVVeIJDh3Oi65pDmJmo8

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict 1wZfsP6GvqG468feYVfKZApXe8h9wioNpTyn5xscZwErVVeIJDh3Oi65pDmJmo8

--
-- PostgreSQL database cluster dump complete
--

