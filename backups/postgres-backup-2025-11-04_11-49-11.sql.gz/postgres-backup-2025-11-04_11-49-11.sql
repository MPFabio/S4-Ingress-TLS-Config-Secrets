--
-- PostgreSQL database cluster dump
--

\restrict t93IIsvo9Fyl38PJNX9pMbUZ4fa692PXYdBa7fq6fMKy0UWriwbXNxd9gFmbL9Y

SET default_transaction_read_only = off;

SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;

--
-- Roles
--

CREATE ROLE postgres;
ALTER ROLE postgres WITH SUPERUSER INHERIT CREATEROLE CREATEDB LOGIN REPLICATION BYPASSRLS PASSWORD 'SCRAM-SHA-256$4096:HfXm+byZP5iiR95hY375QQ==$kUAhkK97s7OxpY39QkK7t8IR8TZ8hkbUJOj+eNmpLgM=:mMTol+KtUmrHC9hsyJg9sF1aq/0rjd2f22lkG+ZKLms=';

--
-- User Configurations
--








\unrestrict t93IIsvo9Fyl38PJNX9pMbUZ4fa692PXYdBa7fq6fMKy0UWriwbXNxd9gFmbL9Y

--
-- Databases
--

--
-- Database "template1" dump
--

\connect template1

--
-- PostgreSQL database dump
--

\restrict juIJC9kWUv7KUDe4P2e13ncdIuvSp686SRyYt3iedSpzfIZfO2IECgkQCazzinH

-- Dumped from database version 16.10 (Debian 16.10-1.pgdg13+1)
-- Dumped by pg_dump version 16.10 (Debian 16.10-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict juIJC9kWUv7KUDe4P2e13ncdIuvSp686SRyYt3iedSpzfIZfO2IECgkQCazzinH

--
-- Database "postgres" dump
--

\connect postgres

--
-- PostgreSQL database dump
--

\restrict sB4GMRdpL5nF117z390osJJeaxzeHqJQDCDNsv5JQo7bOhT2lSbS5IKVcg6jf8g

-- Dumped from database version 16.10 (Debian 16.10-1.pgdg13+1)
-- Dumped by pg_dump version 16.10 (Debian 16.10-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict sB4GMRdpL5nF117z390osJJeaxzeHqJQDCDNsv5JQo7bOhT2lSbS5IKVcg6jf8g

--
-- Database "workshop" dump
--

--
-- PostgreSQL database dump
--

\restrict OeweEVN6gCsMyPIBEj0zIrkCI0ifZ40T81W5ciqPoODZd3wtp0yw1pJIipwLB03

-- Dumped from database version 16.10 (Debian 16.10-1.pgdg13+1)
-- Dumped by pg_dump version 16.10 (Debian 16.10-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: workshop; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE workshop WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


ALTER DATABASE workshop OWNER TO postgres;

\unrestrict OeweEVN6gCsMyPIBEj0zIrkCI0ifZ40T81W5ciqPoODZd3wtp0yw1pJIipwLB03
\connect workshop
\restrict OeweEVN6gCsMyPIBEj0zIrkCI0ifZ40T81W5ciqPoODZd3wtp0yw1pJIipwLB03

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict OeweEVN6gCsMyPIBEj0zIrkCI0ifZ40T81W5ciqPoODZd3wtp0yw1pJIipwLB03

--
-- PostgreSQL database cluster dump complete
--

